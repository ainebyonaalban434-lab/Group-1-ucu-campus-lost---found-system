# Contribution Log – CSC1202 Group 1

Each member confirms their own row. Record only work that was actually completed and can be shown in the repository history or other evidence. If you worked offline or with another GitHub account, say so and give the evidence.

| Member | Role | Actual contribution (member to confirm) | Evidence (commit IDs / files) |
|---|---|---|---|
| Ainebyona Alban | Role 1 – Project leadership, backend and database | Backend (Node.js/Express), MySQL schema, authentication, sessions, claims and admin routes, backend/database documentation | Three commits on main (to be listed by Alban) |
| Yanya Favour | Role 2 – Frontend | React frontend pages and styles, frontend handover report | One commit on main (to be listed by Yanya) |
| Mutebi Brian John | Role 3 – QA and testing | QA test report | QA report commit (GitHub account to be confirmed by Brian) |
| Chebet Esther Cherotich | Role 4 – Documentation and presentation | Project report draft, corrected QA report template, defence questions, presentation notes, this contribution log | Commit IDs to be added after the commit below |
| Kinyera Daniel (Danny) | Role 5 – Integration and deployment | System integration and deployment handover document | Commit IDs to be added by Danny |

## Notes
- Group members: five, as listed above.
- Do not claim another person's work.
