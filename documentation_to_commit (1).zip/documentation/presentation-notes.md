# Presentation Notes – Group 1 (15 minutes)

| Time | Part | Speaker |
|---|---|---|
| 2 min | Problem and design | Esther |
| 6 min | Live demo and mobile view | Yanya and Alban |
| 4 min | Technical questions | Whole group, each answers on their own part |
| 3 min | Small code change | Member who owns that code |

## Opening (about 2 minutes) – Esther
1. Okello lost his keys. Namusoke found them the same day. Both used WhatsApp, but their messages reached different people.
2. There was no shared place to search, to prove ownership privately, or to record that the keys were returned.
3. Our solution is the UCU Campus Lost and Found System. Students report lost or found items, search, and submit private claims. An administrator reviews claims and confirms return.
4. Private details and claim evidence are never shown publicly, and this is enforced on the backend.
5. Technology: React, Node.js and Express, MySQL. Show the ER diagram: users, item_reports, claims, sessions.

## Demo order
1. Student reports a found item (privacy notice shown).
2. Another student searches and finds it.
3. That student submits a private claim.
4. Administrator approves the claim. The report stays OPEN.
5. Administrator confirms return. The report becomes RETURNED.
6. Try to claim the returned item: refused.
7. Show the same screens at mobile width.

Keep the local version running as a backup in case campus internet fails.
