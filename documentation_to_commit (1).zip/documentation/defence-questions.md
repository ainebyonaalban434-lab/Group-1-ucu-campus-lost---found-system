# Technical Defence Questions and Answers – Group 1

Short answers based on the project's documentation. Each member should be able to explain the part they worked on in their own words. Items marked CHECK must be confirmed in the real code before the defence.

## Architecture
**1. How is the system structured?** Three tiers: a React frontend, a Node.js and Express backend that exposes a JSON API, and a MySQL database. The frontend never connects to the database directly.

**2. Why does the frontend not connect to MySQL directly?** Database credentials and business rules must stay on the server, where users cannot change them.

## Login and security
**3. How are passwords stored?** Hashed with bcryptjs (cost factor 10). The original password is never stored or returned.

**4. How does login work?** The backend finds the user by email, compares the password with the stored hash, regenerates the session and saves it. The browser keeps a session cookie named ucu.sid. Sessions last eight hours and are stored in MySQL.

**5. Why regenerate the session after login?** It reduces the risk of session fixation.

**6. Difference between 401 and 403?** 401 means the user is not logged in. 403 means the user is logged in but not allowed, for example a student calling an admin route.

**7. How is SQL injection prevented?** All queries are parameterised: the values are sent separately from the SQL text.

**8. How are private details protected?** Public report responses leave out private_details. Claim evidence is returned only to the claimant and the administrator. This is enforced on the backend, not only by hiding things on the screen.

## Database
**9. What are the tables?** users, item_reports, claims and sessions.

**10. What is the relationship between them?** One user has many reports and many claims; one report has many claims; reviewed_by links a claim to the administrator who reviewed it and stays empty until review.

**11. How are duplicate claims prevented?** CHECK in schema.sql: the database documentation says transactions with row locking and a non-unique index; the ER explanation mentions a unique constraint (uq_claims_item_claimant). Answer only with what the schema really contains.

**12. What does ON DELETE CASCADE do here?** Deleting a user or report also deletes the related reports or claims. Deleting a reviewer sets reviewed_by to NULL.

## Claims and returns
**13. What is the difference between approving a claim and returning an item?** Approval means the claim is accepted for collection. The item becomes RETURNED only after the administrator confirms physical collection.

**14. What stops two people being approved for one item?** The backend starts a transaction, locks the claim and its report (SELECT ... FOR UPDATE), checks for another approved claim, then updates. Other requests wait for the lock.

**15. What is a race condition?** Two requests check the same data before either saves, so both succeed when only one should. Transactions and row locking reduce this.

**16. What stops a claim on a returned item?** The backend checks the report status inside the transaction and refuses the claim.

## Tracing one action
**17. Trace "admin approves a claim".** React sends PATCH /api/admin/claims/:id with the decision and response, and the browser sends the ucu.sid cookie. The requireAdmin middleware checks the session and the ADMIN role. The route validates the input, starts a transaction, locks the claim and report, checks the report is not returned and no other claim is approved, updates the claim and reviewed_by, commits, and returns JSON. The page then shows the new status.

## Limitations (answer honestly)
**18. What is not finished?** Photo upload (only an image link is stored), automated tests, a concurrency stress test, rate limiting, account recovery, audit logging. Production use needs HTTPS and a review of cookie and CORS settings.
